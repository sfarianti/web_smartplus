<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    protected $table = 'tb_selesai'; 
    public $timestamps = false;
    
}
